package com.example.doctor_suggesting_system

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Doctor : AppCompatActivity() {

    private val doctorsList = mutableListOf<Doctor>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor)


        val selectedSymptoms = intent.getStringArrayListExtra("SYMPTOMS") ?: emptyList()
        val doctorsWithAddress = getDoctorsBySymptoms(selectedSymptoms)
        val doctorsList = doctorsWithAddress.map { it.first }

        val recyclerView = findViewById<RecyclerView>(R.id.doctorsRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = DoctorAdapter(doctorsList)
    }



    private fun getDoctorsBySymptoms(symptoms: List<String>): MutableList<Pair<Doctor, String>> {
        val doctorsWithAddress = mutableListOf<Pair<Doctor, String>>()

        val symptomOptions = listOf(
            "Cough",
            "Fever",
            "Sore Throat",
            "Headache",
            "Fatigue",
            "Shortness of Breath",
            "Body Aches",
            "Loss of Taste or Smell"
        )

        val allDoctors = listOf(
            Doctor("Dr. John Doe", "General Physician", listOf(symptomOptions[1], symptomOptions[6], symptomOptions[5]), "123 Main St"),
            Doctor("Dr. Emily Smith", "Dermatologist", listOf(symptomOptions[0], symptomOptions[6], symptomOptions[4]), "456 Elm St"),
            Doctor("Dr. David Johnson", "Psychiatrist", listOf(symptomOptions[4], symptomOptions[7], symptomOptions[2]), "789 Oak St"),
            Doctor("Dr. Michael Williams", "Cardiologist", listOf(symptomOptions[1], symptomOptions[5], symptomOptions[3]), "101 Maple Ave"),
            Doctor("Dr. Sarah Brown", "Pediatrician", listOf(symptomOptions[0], symptomOptions[1], symptomOptions[2]), "222 Pine St"),
            Doctor("Dr. Jennifer Lee", "Oncologist", listOf(symptomOptions[3], symptomOptions[5], symptomOptions[6]), "333 Cedar St"),
            Doctor("Dr. Richard Davis", "Orthopedic Surgeon", listOf(symptomOptions[6], symptomOptions[2], symptomOptions[5]), "444 Birch St"),
            Doctor("Dr. Lisa Taylor", "ENT Specialist", listOf(symptomOptions[7], symptomOptions[5], symptomOptions[4]), "555 Walnut St"),
            Doctor("Dr. Robert Clark", "Gynecologist", listOf(symptomOptions[2], symptomOptions[6], symptomOptions[4]), "666 Oak St"),
            Doctor("Dr. Nancy Wilson", "Urologist", listOf(symptomOptions[1], symptomOptions[2], symptomOptions[3]), "777 Elm St")
        )


        for (doctor in allDoctors) {
            if (doctor.symptoms.intersect(symptoms).isNotEmpty()) {
                val address = doctor.address
                doctorsWithAddress.add(Pair(doctor, address))
            }
        }

        return doctorsWithAddress
    }



    inner class DoctorAdapter(private val doctors: List<Doctor>) :
        RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder>() {

        inner class DoctorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val doctorNameTextView: TextView = itemView.findViewById(R.id.doctorNameTextView)
            val specializationTextView: TextView = itemView.findViewById(R.id.specializationTextView)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.doctor_item, parent, false)
            return DoctorViewHolder(view)
        }

        override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
            val doctor = doctors[position]
            holder.doctorNameTextView.text = doctor.name
            holder.specializationTextView.text = doctor.specialization

            holder.itemView.setOnClickListener {
                val intent = Intent(this@Doctor, BookSlotActivity::class.java)
                intent.putExtra("DOCTOR_NAME", doctor.name)
                intent.putExtra("DOCTOR_ADDRESS", doctor.address)
                startActivity(intent)
            }
        }

        override fun getItemCount(): Int = doctors.size
    }


    data class Doctor(val name: String, val specialization: String, val symptoms: List<String>, val address: String)

}