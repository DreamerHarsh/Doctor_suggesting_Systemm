package com.example.doctor_suggesting_system

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.example.doctor_suggesting_system.databinding.ActivitySymptomsBinding
import com.google.android.material.navigation.NavigationView
import java.util.Random

class Symptoms : AppCompatActivity() {


    private lateinit var binding : ActivitySymptomsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySymptomsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val patientName = intent.getStringExtra("PATIENT_NAME")

        var patient = findViewById<TextView>(R.id.textView2)

        patient.setText("Welcome, " + patientName);


        var toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.setTitle("Doctor Suggesting System")
        setSupportActionBar(toolbar)

        toolbar.setNavigationOnClickListener{
            Toast.makeText(this, "Logo", Toast.LENGTH_LONG).show()
        }


        binding.submitButton.setOnClickListener {
            val symptoms = mutableListOf<String>()
            if (binding.cough.isChecked) symptoms.add("Cough")
            if (binding.fever.isChecked) symptoms.add("Fever")
            if (binding.soreThroat.isChecked) symptoms.add("Sore Throat")
            if (binding.headache.isChecked) symptoms.add("Headache")
            if (binding.fatigue.isChecked) symptoms.add("Fatigue")
            if (binding.shortnessOfBreath.isChecked) symptoms.add("Shortness of Breath")
            if (binding.bodyAches.isChecked) symptoms.add("Body Aches")
            if (binding.lossOfTasteOrSmell.isChecked) symptoms.add("Loss of Taste or Smell")

            if (symptoms.isEmpty()) {
                showAlertDialog()
            } else {
                val intent = Intent(this@Symptoms, Doctor::class.java)
                intent.putStringArrayListExtra("SYMPTOMS", ArrayList(symptoms))
                startActivity(intent)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_toolbar,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id:Int = item.itemId
        if (id==R.id.settings){
            Toast.makeText(this, "Setting Clicked", Toast.LENGTH_LONG).show()

        }
        else if (id==R.id.bg_color){
            Toast.makeText(this, "Color Changed", Toast.LENGTH_LONG).show()
            findViewById<View>(R.id.drawerLayout).setBackgroundColor(getRandomColor())

        }
        return super.onOptionsItemSelected(item)
    }

    private fun getRandomColor(): Int {
        val random = Random()
        return Color.argb(255, random.nextInt(256), random.nextInt(256), random.nextInt(256))
    }

    private fun showAlertDialog() {
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Selection Required")
        alertDialogBuilder.setMessage("Please select at least one symptom.")
        alertDialogBuilder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }
}


