package com.example.doctor_suggesting_system

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.DatePicker
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar

class BookSlotActivity : AppCompatActivity() {

    private lateinit var bookingDateEditText: EditText
    private lateinit var bookingTimeEditText: EditText
    private lateinit var rating: RatingBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_slot)

        val doctorNameTextView = findViewById<TextView>(R.id.doctorNameTextView)
        val doctorAddressTextView = findViewById<TextView>(R.id.doctorAddressTextView)
        val userNameEditText = findViewById<EditText>(R.id.userNameEditText)
        val userAgeEditText = findViewById<EditText>(R.id.userAgeEditText)
        val userGenderSpinner = findViewById<Spinner>(R.id.userGenderSpinner)
        bookingDateEditText = findViewById(R.id.bookingDateEditText)
        bookingTimeEditText = findViewById(R.id.bookingTimeEditText)
        val submitButton = findViewById<Button>(R.id.submitButton)
        val simpleRating = findViewById<RatingBar>(R.id.ratingBar)

        val doctorName = intent.getStringExtra("DOCTOR_NAME")
        val doctorAddress = intent.getStringExtra("DOCTOR_ADDRESS")

        doctorNameTextView.text = "Doctor Name: $doctorName"
        doctorAddressTextView.text = "Doctor Address: $doctorAddress"

        bookingDateEditText.setOnClickListener {
            showDatePicker()
        }

        bookingTimeEditText.setOnClickListener {
            showTimePicker()
        }


        submitButton.setOnClickListener {
            val userName = userNameEditText.text.toString()
            val userAge = userAgeEditText.text.toString().toIntOrNull()
            val userGender = userGenderSpinner.selectedItem.toString()
            val bookingDate = bookingDateEditText.text.toString()
            val bookingTime = bookingTimeEditText.text.toString()
            val totalstars = "Total Stars: " + simpleRating.numStars
            val rating = "Rating " + simpleRating.rating
            Toast.makeText(this, """$totalstars$rating""".trimIndent(), Toast.LENGTH_LONG).show()


            if (userName.isNotEmpty() && userAge != null && bookingDate.isNotEmpty() && bookingTime.isNotEmpty()) {
                val successMessage = "Slot booked successfully!\n\n" +
                        "Patient Details:\n" +
                        "Name: $userName\n" +
                        "Age: $userAge\n" +
                        "Gender: $userGender\n\n" +
                        "Doctor Details:\n" +
                        "Name: $doctorName\n" +
                        "Address: $doctorAddress\n" +
                        "Booking Date: $bookingDate\n" +
                        "Booking Time: $bookingTime"

                val dialog = AlertDialog.Builder(this)
                    .setTitle("Booking Successful")
                    .setMessage(successMessage)
                    .setPositiveButton("OK") { dialog, _ ->
                        val intent = Intent(this@BookSlotActivity, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                        dialog.dismiss()
                    }
                    .create()
                dialog.show()
            } else {
                Toast.makeText(this, "Please fill all the fields.", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, monthOfYear, dayOfMonth ->
                bookingDateEditText.setText("$dayOfMonth/${monthOfYear + 1}/$year")
            },
            year,
            month,
            day
        )
        datePickerDialog.show()
    }

    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                bookingTimeEditText.setText(String.format("%02d:%02d", hourOfDay, minute))
            },
            hour,
            minute,
            true
        )
        timePickerDialog.show()
    }
}